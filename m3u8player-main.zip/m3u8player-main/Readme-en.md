Based on html + tencent sdk development of m3u8 online player, to achieve mp4, m3u8/hls format video online playback

[English version](https://github.com/geeeeeeeek/m3u8player/blob/main/README-en.md)


## Preview

https://m3u8player.org/en


## Deployment steps

1.Apply for the licenceUrl of cloud broadcasting SDK, the application address is https://console.cloud.tencent.com/vcube/web?tab=player

2.Fill the licenseUrl of the application into the licenseUrl of the script.

3. Copy all the files in the directory to the server.



## Reference

- [m3u8player](https://m3u8player-cm4.pages.dev/)

- [vercel-alpha](https://m3u8player-alpha.vercel.app/)


